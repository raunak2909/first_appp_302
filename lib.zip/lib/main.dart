import 'package:first_appp_302/domain/utils/app_constant.dart';
import 'package:first_appp_302/ui/secondPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:first_appp_302/ui/home_page.dart';

void main(){

  runApp(MainApp());

}


/*class App{

  static String name = "Walcano";
  String address = "fsvfkenv";
}*/

class MainApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      home: HomePage(), //20 times
    );
  }
}

