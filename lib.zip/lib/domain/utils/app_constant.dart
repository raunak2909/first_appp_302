class AppConstants{
  static final String appName = "Classico";
  static final String appDesc = "One solution for all your problems";
}