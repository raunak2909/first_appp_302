import 'dart:ui';

class AppColors{

  static final Color primaryColor = Color(0xff48AF4A);
  static final Color secondaryColor = Color(0xff14635A);

}